package com.practice.service;

import com.practice.entity.Sale;

public interface SaleService {

	Sale saveSale(Sale sale);

}
