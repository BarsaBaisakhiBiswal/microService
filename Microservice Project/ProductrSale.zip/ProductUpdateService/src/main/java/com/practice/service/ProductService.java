package com.practice.service;

import java.util.List;

import com.practice.entity.ProductEntity;

public interface ProductService {

	ProductEntity save(ProductEntity productEntity);

}
