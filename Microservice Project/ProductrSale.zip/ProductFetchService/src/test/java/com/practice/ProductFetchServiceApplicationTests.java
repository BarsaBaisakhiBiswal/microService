package com.practice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductFetchServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
